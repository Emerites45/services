

module.exports = (sequelize, DataTypes) => {
    return sequelize.define('date', {
      id_date: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },

      date: DataTypes.DATE,
      
      timestamps: true,
      createdAt: 'date_creation',
      updatedAt: false
    })
  }