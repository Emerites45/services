

module.exports = (sequelize, DataTypes) => {
    return sequelize.define('objet', {
      id_objet: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },

      nom: {
      
        type: DataTypes.STRING,
        allowNull: false,
        unique:{
          msg: 'ce titre est deja pris' 
       },
        validate: {
          notEmpty: {msg: 'Le nom  ne doit pas être vide'},
          notNull: {msg: 'Le nom  est une propriété requise'}
        }},
      description: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: {msg: `description ne doit pas être vide`},
          notNull: {msg: `Votre description est obligatoire merci de le renseigner`}
        }
      },
      categorie: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: {msg: `categorie ne doit pas être vide`},
          notNull: {msg: `Votre categorie est obligatoire merci de le renseigner`}
        }
      },
      etat:{
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: {msg: `etat ne doit pas être vide`},
          notNull: {msg: `Votre etat est obligatoire merci de le renseigner`}
        }
      },

      type:{
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: {msg: `type ne doit pas être vide`},
          notNull: {msg: `Votre type est obligatoire merci de le renseigner`}
        }
      },

      id_utilisateur:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          notEmpty: {msg: `type ne doit pas être vide`},
          notNull: {msg: `Votre type est obligatoire merci de le renseigner`}
        }
      }, 
      lieuIdLieu:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          notEmpty: {msg: `type ne doit pas être vide`},
          notNull: {msg: `Votre type est obligatoire merci de le renseigner`}
        }
      },
      dateIdDate:{
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          notEmpty: {msg: `type ne doit pas être vide`},
          notNull: {msg: `Votre type est obligatoire merci de le renseigner`}
        }
      },
     
    
     
    }, {
      timestamps: true,
      createdAt: 'date_creation',
      updatedAt: false
    })
  }