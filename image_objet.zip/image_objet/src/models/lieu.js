

module.exports = (sequelize, DataTypes) => {
    return sequelize.define('lieu', {
      id_lieu: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },

      ville: {
      
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: {msg: 'Le ville ne doit pas être vide'},
          notNull: {msg: 'Le ville  est une propriété requise'}
        }},
      region: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: {msg: `region ne doit pas être vide`},
          notNull: {msg: `Votre region est obligatoire merci de le renseigner`}
        }
      },
      departement : {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: {msg: `departement ne doit pas être vide`},
          notNull: {msg: `Votre departement est obligatoire merci de le renseigner`}
        }
      },
     
    }, {
      timestamps: true,
      createdAt: 'date_creation',
      updatedAt: false
    })
  }