
const objetmodels=require("../models/objet")
const lieumodels=require("../models/lieu")
const datemodels= require("../models/date")
const imagemodels=require("../models/Images")



const { Sequelize, DataTypes } = require('sequelize')

  
const sequelize = new Sequelize('bd', 'root', '', {
  host: 'bd.sqlite',
  dialect: 'sqlite',
  dialectOptions: {
    timezone: 'Etc/GMT-2',
  },
  logging:true
})

const Objet=objetmodels(sequelize,DataTypes);
const Lieu=lieumodels(sequelize,DataTypes);
const Image=imagemodels(sequelize,DataTypes);
const Dates=datemodels(sequelize,DataTypes);




// Relation Objet -> Lieu
Objet.belongsTo(Lieu);
Objet.belongsTo(Dates);



Objet.hasMany(Image,{
  foreignKey:'id_objet',
  as: 'image_Objet',
  onDelete:'CASCADE'
})

Image.belongsTo(Objet,{
  foreignKey: 'id_objet',
  as: 'image_Objet',
 
  hooks:true
})
const initDb = () => {
    return sequelize.sync({force: true}).then(_ => {
      console.log('La base de donnée a bien été initialisée !')
    })
  }
    
  
  module.exports = { 
   sequelize,Image,Objet,Lieu,Dates
  }