const { Objet }= require('../db/sequelize')
const {Image}= require('../db/sequelize')
const{Lieu}=require('../db/sequelize')
const{Dates}=require('../db/sequelize')
const cors=require("cors")
const compare=require("lodash")
const enregistrer_image_video= require("../fonctions/modifier_image")
const suppression=require("../fonctions/supprimer_image")
const path= require("path")
const {ValidationError}= require('sequelize')
const {UniqueConstraintError}=require('sequelize')

var objet =require("../models/objet")
var lieu =require("../models/lieu")
var date =require("../models/date")

const multer =require("multer");

var tab=[]
var tab1=[]

const uploadDir = path.join(__dirname, './public/data');
//const imagePath = path.join(uploadDir, 'uploads', `${filename}.jpg`);


const  MIME_TYPES={
 "image/jpg" : "jpg",
 "image/jpeg":"jpg",
 "image/gif":"gif",
 "image/png": "png",
 "image/bmp":"bmp"
}


const storage =multer.diskStorage({
 destination : (req,file,cb)=>
 {
    cb(null,"./public/data/uploads/images")
 },
 filename : (req,file,cb)=>{
   const name=file.originalname.split(" ").join("_")
   const extention= MIME_TYPES[file.mimetype]

   

    cb(null, name+ "_"+Date.now()+ "."+extention);
 }
})


const upload= multer({storage:storage,
 

 }
 )

module.exports =(app) =>{
    app.put('/api/objet/modifier/:id',upload.any('file') , cors(),async(req,res) =>
    {
        const id= req.params.id
        tab1= req.files

        console.log(req.files)
        if( compare.isEqual(tab1,tab)===false){
           

            Image.findOne( {where: {
                id_objet: req.params.id}}) .then(image=> {
                    if(image===null){
                        const message="l'image n'existe pas, essayer un autre identifiant "
                        return res.status(404).json({message}) 
                    }
                    console.log(  "caracteristique du: "+image)
                   suppression.supprimer(image.path)
                    enregistrer_image_video.modifier(req.files,id,null)
                   })

                    

              
}
else 
{
    console.log('yo image doit pas etre supprimer')
}

objet= await Objet.findOne( {where: {
    id_objet: req.params.id}})

    if( req.body.nom!=="undefined")
    {
        objet.nom=req.body.nom
    } 
    if( req.body.description!=="undefined")
    {
        objet.description=req.body.description
    } 
    if( req.body.categorie!=="undefined")
    {
        objet.categorie=req.body.categorie
    } 
    if( req.body.etat!=="undefined")
    {
        objet.etat=req.body.etat
    } 
    if( req.body.type!=="undefined")
    {
        Objet.type=req.body.type
    } 

    if( req.body.date!=="undefined")
    {
        date.date=req.body.date
    } 

    if( req.body.ville!=="undefined")
    {
        lieu.ville=req.body.ville
    } 
    if( req.body.region!=="undefined")
    {
        lieu.region=req.body.region
    } 

    if( req.body.departement!=="undefined")
    {
        lieu.departement=req.body.departement
    } 

Lieu.update(lieu,{where: {id_lieu:objet.lieuIdLieu }})
console.log(objet)
console.log(date)
console.log(lieu)
Dates.update(date,{where: {id_date:objet.dateIdDate}})


    await   Objet.update(objet,{
            where: {id_objet: id}

        })
        .then(_=>{
        Objet.findOne( {where: {
            id_Objet: req.params.id}}).then(Objets => {
                if(Objets===null)
                {  
                    console.log(Objets)
                    
                    const message="le Objets n'existe pas "
                        res.status(404).json({message}) 
                    
                }
                const message='le Objets a bien ete modifie.'
                res.json({message})
            })
        
        
        }).catch(error =>{
                const message="le Objets n'a pas pue etre modifier,reesayer dans quelques instant"
                console.log(error)
                res.status(500).json({message,data: error}) 
               
            }).catch(error => {
                if(error instanceof ValidationError ){
                return res.status(400).json({message: error.message,data: error})
               }
               if(error instanceof UniqueConstraintError){
                return res.status(400).json({message: error.message})
               }
               
            })
        })
    }
