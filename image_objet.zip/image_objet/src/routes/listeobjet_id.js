const {Objet}= require('../db/sequelize')
const {Lieu}= require('../db/sequelize')
const {Dates}= require('../db/sequelize')
const cors= require('cors')



module.exports= (server) => {
   server.get('/api/objet/:id',cors(),async(req,res)=>{

    

    Objet.findOne({

      include: [{ model: Lieu},{model: Dates }],
       where: {
      id_objet: req.params.id}
      
     

   })
       .then(Objet => {
        
         res.json(Objet )
       })
       .catch(error => {
         const message = `La formation  n'a pas pu être récupérée. Réessayez dans quelques instants.`
         res.status(500).json({message, data:error})
         console.log(error)
       })
   })
}