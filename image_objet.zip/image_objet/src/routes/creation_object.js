
const {Objet}= require('../db/sequelize')
const {Lieu}= require('../db/sequelize')
const {Dates}= require('../db/sequelize')
const {ValidationError}= require('sequelize')
const {UniqueConstraintError}=require('sequelize')

const path= require("path")
const multer =require("multer");

const cors= require("cors")

 var images = require("../fonctions/enregistrer_images")

 var tab=[]

const uploadDir = path.join(__dirname, './public/data');
//const imagePath = path.join(uploadDir, 'uploads', `${filename}.jpg`);


const  MIME_TYPES={
  "image/jpg" : "jpg",
  "image/jpeg":"jpg",
  "image/gif":"gif",
  "image/png": "png",
  "image/bmp":"bmp",
  "video/mp4" : "mp4"
}


const storage =multer.diskStorage({
  destination : (req,file,cb)=>
  {
     cb(null,"./public/data/uploads/images")
  },
  filename : (req,file,cb)=>{
    const name=file.originalname.split(" ").join("_")
    const extention= MIME_TYPES[file.mimetype]

    

     cb(null, name+ "_"+Date.now()+ "."+extention);
  }
})


 const upload= multer({storage:storage,
  

  }
  )



var objet = require('../models/objet')

var lieu = require('../models/objet')
var lieu2 = require('../models/objet')

var date = require('../models/objet')

var date2 = require('../models/objet')

module.exports= (server) => {
   server.post('/api/creation/objet/:id'/*,requireAuth*/,upload.any('file'),cors(),async(req,res)=>{
   

    date.date = req.body.date


    lieu.ville= req.body.ville
    lieu.region=req.body.region
    lieu.departement= req.body.departement 


    objet.nom=req.body.nom;
   
    objet.categorie=req.body.categorie
    objet.etat=req.body.etat
    objet.type=req.body.type
    objet.description=req.body.description;
    objet.id_utilisateur=req.params.id
    



  await Dates.create(date).then(dates=>{ date2=dates});
  await  Lieu.create(lieu).then(lieux=>{lieu2=lieux});;
   console.log(lieu2.id_lieu)
     objet.lieuIdLieu=lieu2.id_lieu
     objet.dateIdDate=date2.id_date
   Objet.create(objet)
    .then(objets =>{
        const message ='le objets a bien ete ajouter.'
     
          
          images.image(req.files,objets.id_objet)



        res.json({message,data: objets})


    }).catch(error => {
     if(error instanceof ValidationError ){
        console.log(error);
     return res.status(400).json({message: error.message,data: error})
    
    }
    if(error instanceof UniqueConstraintError){
     return res.status(400).json({message: error.message})
    }
    const message="la objets n'a pas pue etre ajouter"

    console.log(error);
    res.status(500).json({message, data:error})
    
 })
 })

    


     
    
}