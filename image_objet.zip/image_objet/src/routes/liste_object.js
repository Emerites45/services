const {Objet}= require('../db/sequelize')
const {Lieu}= require('../db/sequelize')
const {Dates}= require('../db/sequelize')


const cors= require('cors')
const requireAuth= require("../auth/isAuth")

module.exports= (server) => {
   server.get('/api/liste/objet'/*,requireAuth*/,cors(),async(req,res)=>{
   
try {

    Objet.findAll({include: [{ model: Lieu},{model: Dates }],}).then(objets => {
        
      res.json(objets)
    })
      }
catch (error ){
        
           res.status(500).json({data: error}) 
           console.log(error)}
       
   }) 
}