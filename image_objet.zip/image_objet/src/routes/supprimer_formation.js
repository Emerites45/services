const {Objet}= require('../db/sequelize');
const {Image}= require('../db/sequelize');
const {Videos_upload}= require('../db/sequelize');
const requireAuth= require("../auth/isAuthadmin")
const cors=require("cors")

const supprimer= require("../fonctions/supprimer_image")


module.exports = (app)=>{
    app.delete('/api/objet/supprimer/:id'/*,requireAuth*/, cors(), async(req,res)=>{

        Videos_upload.findAll({
            where: {
                id_objet: req.params.id}
          }) .then(videos =>{
        
            console.log(videos)

            videos.forEach(element => {
                supprimer.supprimer(element.path )
            });
          
    
             })
    
        
      
           Image.findOne({
        where: {
            id_objet: req.params.id}
      }) .then(Images =>{
    
        console.log(Images)
        supprimer.supprimer(Images.path )

         })

     

        Objet.findOne({ where: {
            id_Objet: req.params.id}}
         )
        .then(Objet => {
            if(Objet===null){
                const message="le Objets n'existe pas, essayer un autre identifiant "
                return res.status(404).json({message}) 
            }

           

           //
            const Objetsdelete=Objet;
            Objet.destroy({
                where : id_Objet=Objet.id_Objet
            }).then()
            return  res.json( Objetsdelete)  
        })

    })
}