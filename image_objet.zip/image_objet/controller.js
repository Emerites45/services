const { default: kafkaconfiguration } = require("./config")
const  kafkaconfiguration= require("./config")






const sendmessagetokafka= async (req,res) =>{
    try {
        
               const {message}= req.body
               
const kafkaconfiguration= new kafkaconfiguration()

const messages = [{
    key:'key1', value: message
}]

kafkaconfiguration.produce("mn-topic",message);


res.status(200).json({
    status:"OK",
    messages:"message envoyé avec succès"
})



    } catch (error) {
        console.log(error)
    }
}

const controller= {sendmessagetokafka};

export default controller